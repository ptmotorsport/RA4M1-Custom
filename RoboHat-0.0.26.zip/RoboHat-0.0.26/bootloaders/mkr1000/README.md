
The source code of the bootloader is in the folder:

  bootloader/zero/


